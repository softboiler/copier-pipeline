from copier.cli import CopierApp

if __name__ == "__main__":
    CopierApp.run()
