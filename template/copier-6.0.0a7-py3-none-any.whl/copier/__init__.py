"""Copier.

Docs: https://copier.readthedocs.io/
"""

from .main import *  # noqa: F401,F403
from .main import run_auto as copy  # noqa: F401; Backwards compatibility

# This version is a placeholder autoupdated by poetry-dynamic-versioning
__version__ = "6.0.0a7"
